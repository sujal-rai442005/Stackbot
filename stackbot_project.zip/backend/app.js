
const express = require('express');
const mongoose = require('mongoose');
const axios = require('axios');
const { Configuration, OpenAIApi } = require('openai');
require('dotenv').config();
const i18next = require('i18next');
const i18nextBackend = require('i18next-node-fs-backend');
const bodyParser = require('body-parser');

const app = express();
app.use(bodyParser.json());

// MongoDB setup
mongoose.connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.error('MongoDB connection error:', err));

// OpenAI setup
const openai = new OpenAIApi(new Configuration({
  apiKey: process.env.OPENAI_API_KEY
}));

// i18next setup for multi-language support
i18next.use(i18nextBackend).init({
  backend: {
    loadPath: './locales/{{lng}}/translation.json'
  },
  lng: 'en', // default language
  fallbackLng: 'en',
  debug: true
});

// Route to fetch stock data
app.post('/get-stock', async (req, res) => {
  const { symbol } = req.body;
  try {
    const response = await axios.get(`https://api.example.com/stock/${symbol}`);
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: 'Error fetching stock data' });
  }
});

// Route to handle chat queries (AI)
app.post('/chat', async (req, res) => {
  const { message, language } = req.body;
  try {
    i18next.changeLanguage(language || 'en');  // Change language dynamically

    // Generate response using OpenAI
    const response = await openai.createCompletion({
      model: "text-davinci-003",
      prompt: message,
      max_tokens: 150,
    });

    const botResponse = response.data.choices[0].text;
    res.json({ response: botResponse });
  } catch (error) {
    res.status(500).json({ error: 'Error processing the message' });
  }
});

// Start the server
app.listen(5000, () => console.log('Server running on port 5000'));
    