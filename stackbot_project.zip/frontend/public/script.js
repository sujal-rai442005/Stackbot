
document.getElementById('sendMessage').addEventListener('click', async () => {
  const userInput = document.getElementById('userInput').value;
  const language = document.getElementById('languageSwitch').innerText.includes('Hindi') ? 'hi' : 'en';

  if (userInput.trim() === '') return;

  // Display user message
  displayMessage(userInput, 'user');

  // Send user input to backend
  const response = await fetch('http://localhost:5000/chat', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ message: userInput, language: language }),
  });

  const data = await response.json();
  displayMessage(data.response, 'bot');
  document.getElementById('userInput').value = '';  // Clear input
});

// Function to display messages in chat
function displayMessage(message, sender) {
  const chatbox = document.getElementById('chatbox');
  const msgDiv = document.createElement('div');
  msgDiv.textContent = message;
  msgDiv.classList.add(sender === 'user' ? 'text-right text-blue-500' : 'text-left text-gray-700');
  chatbox.appendChild(msgDiv);
  chatbox.scrollTop = chatbox.scrollHeight;
}

// Switch language
document.getElementById('languageSwitch').addEventListener('click', () => {
  const currentLanguage = document.getElementById('languageSwitch').innerText;
  if (currentLanguage.includes('Hindi')) {
    document.getElementById('languageSwitch').innerText = 'Switch to English';
  } else {
    document.getElementById('languageSwitch').innerText = 'Switch to Hindi';
  }
});
    